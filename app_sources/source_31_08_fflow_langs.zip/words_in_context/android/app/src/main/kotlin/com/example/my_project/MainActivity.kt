package com.mycompany.wordsincontext

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
